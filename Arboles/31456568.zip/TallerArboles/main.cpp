#include <iostream>
#include <sstream>
#include <string>
#include <list>
#include <chrono> // Librería para medir el tiempo
#include <windows.h>
#include "lib/arbol.hpp"
using namespace std;

int main(){
     // 1. Obtener el tiempo justo antes de ejecutar el código a medir
    auto inicio = std::chrono::high_resolution_clock::now();

    // --- INICIO DEL CÓDIGO QUE QUIERES MEDIR ---

    // (Simulamos un trabajo pesado o una tarea larga)
    cout << "Iniciando una tarea pesada..." << endl;
    Sleep(2000);
    cout << "Tarea finalizada." << endl;


    int casos;
    int padre;
    int hijo;
    int nodos;
    int valor;
    ArbolN<Estudiante> arbol;
    list<int> efiLocales;

    // Lee la entrada
    cin >> casos;
    for(int i = casos; i > 0; i--){
        cin >> nodos;
        for(int j = nodos; j > 0; j--){
            cin >> valor;
            efiLocales.push_back(valor);
        }
        list_utils::imprimir(efiLocales);
        Estudiante estudianteRaiz(1, efiLocales.front());
        //estu.imprimirEstudiante();
        efiLocales.pop_front();
        ArbolN<Estudiante> arbol(estudianteRaiz); // Ingresar la raiz
        // Rellenar el Arbol con los elementos de la entrada
        for(int j = nodos -1; j > 0; j--){
            cin >> padre;
            cin >> hijo;
            //cout << "paso:" << endl;
            //cout << "\n" << padre << " - " << hijo << endl;
            arbol.insertarNodoPorPadre(padre, hijo, efiLocales.front());
            efiLocales.pop_front();
            
        }


        arbol.imprimirArbolEstudiantes();
        int balance = arbol.balanceHojas();
        int maxSum = arbol.maxSumaIndependiente();
        int chupa = balance * maxSum;
        cout << balance << " -- " << maxSum << endl;
        cout << "CHUPA: " << chupa << endl;
    }


     // 2. Obtener el tiempo justo al finalizar
    auto fin = chrono::high_resolution_clock::now();

    // 3. Calcular la duración restando el tiempo de inicio al de fin
    chrono::duration<double> duracion_segundos = fin - inicio;

    // 4. Mostrar el resultado
    cout << "\n--- Resultados del Tiempo de Ejecucion ---" << endl;
    cout << "Tiempo total: " << duracion_segundos.count() << " segundos." << endl;
    return 0;
}